## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5
)

## ----setup--------------------------------------------------------------------
library(vecshift)
library(data.table)

## ----default-states-----------------------------------------------------------
# View default classification rules
default_rules <- get_default_status_rules()

# Print the structure of default rules
cat("Default Employment Status Categories:\n\n")

cat("1. Unemployment (arco = 0):\n")
cat("   - disoccupato: No active contracts\n\n")

cat("2. Single Employment (arco = 1):\n")
cat("   - occ_ft: Full-time employment (prior = 1)\n")
cat("   - occ_pt: Part-time employment (prior = 0)\n\n")

cat("3. Overlapping Employment (arco > 1):\n")
cat("   - over_pt_ft: Transition from part-time to full-time\n")
cat("   - over_ft_pt: Transition from full-time to part-time\n")
cat("   - over_pt_pt: Multiple part-time employments\n")
cat("   - over_ft_ft: Multiple full-time employments\n")

## ----default-example----------------------------------------------------------
# Create sample employment data with various scenarios
sample_data <- data.table(
  id = 1:5,
  cf = c("P001", "P001", "P001", "P002", "P002"),
  INIZIO = as.Date(c("2023-01-01", "2023-03-01", "2023-07-01", 
                      "2023-02-01", "2023-05-01")),
  FINE = as.Date(c("2023-02-28", "2023-06-30", "2023-12-31",
                    "2023-04-30", "2023-08-31")),
  prior = c(1, 0, 1, 1, 0)  # Mix of full-time and part-time
)

print("Input employment data:")
print(sample_data)

# Apply vecshift with default classification
result <- vecshift(sample_data)

print("\nProcessed segments with status classification:")
print(result[, .(cf, inizio, fine, arco, prior, stato, durata)])

## ----custom-rules-------------------------------------------------------------
# Example 1: Custom rules for a specific industry
industry_rules <- create_custom_status_rules(
  unemployment_threshold = 15,  # Different threshold for unemployment
  custom_labels = list(
    unemployed_short = "temporary_layoff",
    unemployed_long = "permanent_layoff",
    full_time = "regular_employee",
    part_time = "contractor"
  )
)

# Apply custom rules
result_custom <- vecshift(sample_data, status_rules = industry_rules)

print("Results with custom industry rules:")
print(result_custom[, .(cf, stato, durata)])

## ----advanced-rules-----------------------------------------------------------
# Create rules with intensity and transition tracking
advanced_rules <- create_custom_status_rules(
  unemployment_threshold = 30,
  custom_labels = list(
    unemployed_short = "job_transition",
    unemployed_long = "career_break",
    full_time = "permanent_staff",
    part_time = "flexible_work",
    overlap_pt_ft = "upgrading_hours",
    overlap_ft_pt = "reducing_hours",
    overlap_pt_pt = "multiple_gigs",
    overlap_ft_ft = "dual_employment"
  ),
  include_intensity = TRUE,
  include_transitions = TRUE
)

# Process with advanced rules
result_advanced <- vecshift(sample_data, status_rules = advanced_rules)

print("Results with advanced classification:")
unique_states <- unique(result_advanced$stato)
cat("Unique employment states found:", paste(unique_states, collapse = ", "), "\n")

## ----raw-segments-------------------------------------------------------------
# Process without status classification
raw_segments <- vecshift(sample_data, classify_status = FALSE)

print("Raw segments without status labels:")
print(raw_segments[, .(cf, inizio, fine, arco, prior, durata)])

# You can apply classification later if needed
classified_later <- classify_employment_status(raw_segments)

print("\nStatus added separately:")
print(classified_later[, .(cf, inizio, fine, stato)])

## ----pattern-analysis---------------------------------------------------------
# Generate more complex data for pattern analysis
complex_data <- data.table(
  id = 1:10,
  cf = rep(c("P001", "P002", "P003"), c(4, 3, 3)),
  INIZIO = as.Date(c("2023-01-01", "2023-04-01", "2023-07-01", "2023-10-01",
                      "2023-02-01", "2023-06-01", "2023-09-01",
                      "2023-03-01", "2023-05-01", "2023-11-01")),
  FINE = as.Date(c("2023-03-31", "2023-06-30", "2023-09-30", "2023-12-31",
                    "2023-05-31", "2023-08-31", "2023-12-31",
                    "2023-04-30", "2023-10-31", "2023-12-31")),
  prior = c(1, 0, 1, 0, 1, 1, 0, 0, 1, 1)
)

# Process and analyze patterns
result_complex <- vecshift(complex_data)
patterns <- analyze_status_patterns(result_complex, include_transitions = TRUE)

# Display pattern analysis
print(patterns)

## ----validation---------------------------------------------------------------
# Validate status classifications
validation <- validate_status_classifications(result_complex)

print(validation)

# Check for specific issues
if (!validation$is_valid) {
  cat("\nValidation issues detected:\n")
  
  if (validation$missing_labels > 0) {
    cat("- Missing labels:", validation$missing_labels, "\n")
  }
  
  if (validation$total_impossible > 0) {
    cat("- Impossible combinations:", validation$total_impossible, "\n")
    
    # Show details of impossible combinations
    for (issue in names(validation$impossible_combinations)) {
      count <- validation$impossible_combinations[[issue]]
      if (count > 0) {
        cat("  *", gsub("_", " ", issue), ":", count, "\n")
      }
    }
  }
}

## ----data-quality-integration-------------------------------------------------
# Check data quality before processing
quality_assessment <- assess_data_quality(complex_data)

# Check if data has quality issues (using production readiness as indicator)
if (!is.null(quality_assessment$quality_score$is_production_ready) && 
    !quality_assessment$quality_score$is_production_ready) {
  cat("Data quality issues detected. Cleaning data...\n")
  
  # Clean data if needed
  clean_data <- clean_employment_data(
    complex_data,
    remove_duplicates = TRUE,
    remove_invalid_dates = TRUE
  )
  
  # Process cleaned data
  result_clean <- vecshift(clean_data)
} else {
  cat("Data quality check passed.\n")
  result_clean <- vecshift(complex_data)
}

## ----integrated-system--------------------------------------------------------
# Use the integrated system for full processing pipeline
integrated_result <- vecshift_integrated(
  complex_data,
  use_fast_core = TRUE,
  enable_validation = TRUE,
  enable_cleaning = FALSE,
  status_rules = NULL,  # Use default rules
  quality_report = TRUE,
  verbose = FALSE
)

# Access different components of the result
cat("Processing summary:\n")
cat("- Input rows:", integrated_result$processing_info$input_rows, "\n")
cat("- Output rows:", integrated_result$processing_info$output_rows, "\n")
cat("- Modules used:", paste(integrated_result$processing_info$modules_used, 
                             collapse = ", "), "\n")

if (!is.null(integrated_result$quality_report)) {
  cat("\nQuality report available with", 
      length(integrated_result$quality_report), "metrics\n")
}

## ----performance-comparison, eval=FALSE---------------------------------------
# # Example: Benchmarking different approaches
# library(microbenchmark)
# 
# # Generate large dataset
# large_data <- data.table(
#   id = 1:10000,
#   cf = rep(paste0("P", 1:1000), each = 10),
#   INIZIO = as.Date("2020-01-01") + sample(0:1000, 10000, replace = TRUE),
#   FINE = as.Date("2020-01-01") + sample(100:1100, 10000, replace = TRUE),
#   prior = sample(0:1, 10000, replace = TRUE)
# )
# 
# # Benchmark different approaches
# benchmark_results <- microbenchmark(
#   with_status = vecshift(large_data),
#   without_status = vecshift(large_data, classify_status = FALSE),
#   custom_rules = vecshift(large_data, status_rules = industry_rules),
#   times = 10
# )
# 
# print(benchmark_results)

## ----validation-practice------------------------------------------------------
# Good practice: Always validate after custom classification
custom_result <- vecshift(sample_data, status_rules = industry_rules)
validation <- validate_status_classifications(custom_result, rules = industry_rules)

if (validation$is_valid) {
  cat("Classification validated successfully\n")
} else {
  cat("Warning: Classification validation failed\n")
}

## ----document-rules-----------------------------------------------------------
# Example: Well-documented custom rules
seasonal_employment_rules <- create_custom_status_rules(
  unemployment_threshold = 60,  # Seasonal workers may have longer gaps
  custom_labels = list(
    unemployed_short = "off_season",      # Normal seasonal gap
    unemployed_long = "extended_break",   # Longer than typical seasonal gap
    full_time = "peak_season_ft",         # Peak season full-time
    part_time = "shoulder_season_pt",     # Shoulder season part-time
    overlap_pt_pt = "multi_seasonal",     # Multiple seasonal jobs
    overlap_ft_ft = "peak_double_shift"   # Peak season multiple full-time
  )
)

# Document the rules
cat("Seasonal Employment Classification Rules:\n")
cat("- Off-season gaps up to 60 days are normal\n")
cat("- Multiple overlapping jobs common during peak season\n")
cat("- Part-time work typical during shoulder seasons\n")


# This file is part of the standard testthat testing infrastructure
# It automatically finds and runs all test files in the testthat/ directory

library(testthat)
library(vecshift)

test_check("vecshift")
## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 8,
  fig.height = 6,
  warning = FALSE,
  message = FALSE
)

# Only run chunks if ggplot2 is available
has_ggplot2 <- requireNamespace("ggplot2", quietly = TRUE)
knitr::opts_chunk$set(eval = has_ggplot2)

if (has_ggplot2) {
  library(vecshift)
  library(ggplot2)
  library(data.table)
}

## ----color-palettes, fig.height = 8-------------------------------------------
if (has_ggplot2) {
  # Create a grid of palette previews
  library(gridExtra)
  
  palettes <- c("main", "desaturated", "bw", "main_bw", "employment", "contracts")
  
  plots <- lapply(palettes, function(pal) {
    preview_vecshift_colors(pal, show_hex = FALSE) +
      theme(plot.title = element_text(size = 10),
            plot.subtitle = element_text(size = 8))
  })
  
  do.call(grid.arrange, c(plots, ncol = 2))
}

## ----basic-colors-------------------------------------------------------------
# Get main dark-toned palette
main_colors <- vecshift_colors("main")
print(main_colors[1:5])

# Get employment-specific colors
emp_colors <- vecshift_colors("employment")
print(emp_colors)

# Get desaturated version
desat_colors <- vecshift_colors("desaturated", n = 5)
print(desat_colors)

## ----advanced-colors----------------------------------------------------------
# Get colors with transparency
alpha_colors <- vecshift_colors("main", n = 3, alpha = 0.7)
print(alpha_colors)

# Reverse color order
reversed_colors <- vecshift_colors("main", n = 4, reverse = TRUE)
print(reversed_colors)

# Black and white for printing
bw_colors <- vecshift_colors("bw", n = 6)
print(bw_colors)

## ----demo-data----------------------------------------------------------------
# Create sample employment data for demonstration
set.seed(123)
sample_data <- data.table(
  month = rep(1:12, 3),
  employment_status = rep(c("occ_ft", "occ_pt", "disoccupato"), each = 12),
  count = c(
    rnorm(12, 1000, 100),  # Full-time
    rnorm(12, 300, 50),    # Part-time  
    rnorm(12, 150, 30)     # Unemployed
  ),
  contract_type = sample(c("permanent", "temporary", "seasonal"), 36, replace = TRUE),
  region = sample(c("North", "Center", "South"), 36, replace = TRUE)
)

## ----basic-theme--------------------------------------------------------------
# Basic plot with vecshift theme
ggplot(sample_data, aes(x = month, y = count, color = employment_status)) +
  geom_line(size = 1.2) +
  geom_point(size = 2.5) +
  scale_color_vecshift("employment") +
  labs(
    title = "Employment Trends Over Time",
    subtitle = "Monthly employment counts by status",
    x = "Month",
    y = "Count",
    color = "Employment Status"
  ) +
  theme_vecshift()

## ----theme-comparison, fig.height = 10----------------------------------------
# Same plot with different themes
p1 <- ggplot(sample_data, aes(x = month, y = count, fill = employment_status)) +
  geom_col(position = "dodge") +
  scale_fill_vecshift("employment") +
  labs(title = "Default ggplot2 Theme", x = "Month", y = "Count") +
  theme_minimal()

p2 <- ggplot(sample_data, aes(x = month, y = count, fill = employment_status)) +
  geom_col(position = "dodge") +
  scale_fill_vecshift("employment") +
  labs(title = "Vecshift Theme", x = "Month", y = "Count") +
  theme_vecshift()

grid.arrange(p1, p2, ncol = 1)

## ----theme-options, fig.height = 10-------------------------------------------
# Different grid options
p1 <- ggplot(sample_data, aes(x = month, y = count)) +
  geom_line(aes(color = employment_status), size = 1) +
  scale_color_vecshift("employment") +
  labs(title = "Major Grid Only") +
  theme_vecshift(grid = "major")

p2 <- ggplot(sample_data, aes(x = month, y = count)) +
  geom_line(aes(color = employment_status), size = 1) +
  scale_color_vecshift("employment") +
  labs(title = "No Grid") +
  theme_vecshift(grid = "none")

p3 <- ggplot(sample_data, aes(x = month, y = count)) +
  geom_line(aes(color = employment_status), size = 1) +
  scale_color_vecshift("employment") +
  labs(title = "X-Axis Only") +
  theme_vecshift(axis = "x", ticks = "x")

p4 <- ggplot(sample_data, aes(x = month, y = count)) +
  geom_line(aes(color = employment_status), size = 1) +
  scale_color_vecshift("employment") +
  labs(title = "Large Text") +
  theme_vecshift(base_size = 16)

grid.arrange(p1, p2, p3, p4, ncol = 2)

## ----employment-timeline------------------------------------------------------
# Create timeline data
timeline_data <- sample_data[, .(total = sum(count)), by = .(month, employment_status)]

ggplot(timeline_data, aes(x = month, y = total, fill = employment_status)) +
  geom_area(position = "stack", alpha = 0.8) +
  scale_fill_vecshift("employment") +
  labs(
    title = "Employment Status Distribution Over Time",
    subtitle = "Stacked area chart showing employment composition",
    x = "Month",
    y = "Total Employment",
    fill = "Status"
  ) +
  theme_vecshift(grid = "major") +
  theme(legend.position = "bottom")

## ----contract-analysis--------------------------------------------------------
# Fix the aggregation - employment_status is already in the grouping variable
# so we don't need to select it again in the summary
contract_summary <- sample_data[, .(
  avg_count = mean(count)
), by = .(contract_type, employment_status)]

ggplot(contract_summary, aes(x = contract_type, y = avg_count, fill = employment_status)) +
  geom_col(position = "dodge", width = 0.7) +
  scale_fill_vecshift("employment") +
  labs(
    title = "Average Employment by Contract Type",
    subtitle = "Comparison across different employment arrangements",
    x = "Contract Type",
    y = "Average Count",
    fill = "Employment Status"
  ) +
  theme_vecshift(grid = "major", ticks = "both") +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "bottom"
  )

## ----regional-distribution----------------------------------------------------
regional_data <- sample_data[, .(total = sum(count)), by = .(region, employment_status)]

ggplot(regional_data, aes(x = region, y = total, color = employment_status)) +
  geom_point(size = 4, alpha = 0.8) +
  geom_line(aes(group = employment_status), size = 1.2) +
  scale_color_vecshift("employment") +
  labs(
    title = "Regional Employment Distribution",
    subtitle = "Employment status across different regions",
    x = "Region",
    y = "Total Count",
    color = "Employment Status"
  ) +
  theme_vecshift(grid = "major") +
  theme(legend.position = "bottom")

## ----accessibility-test-------------------------------------------------------
# Test accessibility of employment palette
cat("Testing employment palette accessibility:\n")
test_vecshift_accessibility("employment")

cat("\n\nTesting main palette accessibility:\n")  
test_vecshift_accessibility("main")

## ----accessibility-encoding---------------------------------------------------
# Using both color and shape for accessibility
ggplot(sample_data, aes(x = month, y = count, color = employment_status, shape = employment_status)) +
  geom_point(size = 3, alpha = 0.8) +
  geom_line(aes(linetype = employment_status), size = 1) +
  scale_color_vecshift("employment") +
  scale_shape_manual(values = c(16, 17, 18)) +
  scale_linetype_manual(values = c("solid", "dashed", "dotted")) +
  labs(
    title = "Accessible Employment Trends",
    subtitle = "Using color, shape, and line type for accessibility",
    x = "Month",
    y = "Count"
  ) +
  theme_vecshift() +
  theme(legend.position = "bottom")

## ----bw-versions, fig.height = 10---------------------------------------------
# Original with full colors
p1 <- ggplot(sample_data, aes(x = month, y = count, fill = employment_status)) +
  geom_col(position = "dodge") +
  scale_fill_vecshift("employment") +
  labs(title = "Full Color Version") +
  theme_vecshift()

# Desaturated version
p2 <- ggplot(sample_data, aes(x = month, y = count, fill = employment_status)) +
  geom_col(position = "dodge") +
  scale_fill_vecshift("desaturated") +
  labs(title = "Desaturated Version") +
  theme_vecshift()

# Black and white version
p3 <- ggplot(sample_data, aes(x = month, y = count, fill = employment_status)) +
  geom_col(position = "dodge", color = "black", size = 0.3) +
  scale_fill_vecshift("bw") +
  labs(title = "Black & White Version") +
  theme_vecshift()

grid.arrange(p1, p2, p3, ncol = 1)

## ----improved-bw-palette------------------------------------------------------
# Compare old vs new B&W palettes
old_bw <- c("#000000", "#2C2C2C", "#4A4A4A", "#6E6E6E", "#8C8C8C")
new_bw <- vecshift_colors("main_bw", n = 5)

# Create comparison
comparison_data <- data.frame(
  index = rep(1:5, 2),
  palette = rep(c("Old B&W", "New B&W"), each = 5),
  color = c(old_bw, new_bw),
  stringsAsFactors = FALSE
)

ggplot(comparison_data, aes(x = index, y = palette, fill = color)) +
  geom_tile(color = "white", size = 1) +
  geom_text(aes(label = color), 
            color = ifelse(comparison_data$color %in% c("#000000", "#2C2C2C", "#4A4A4A"), 
                          "white", "black"),
            size = 3, fontface = "bold") +
  scale_fill_identity() +
  labs(
    title = "Vecshift B&W Palette Improvement",
    subtitle = "New palette uses lighter, more readable grays",
    x = "Color Index", y = "Palette Version"
  ) +
  theme_vecshift() +
  theme(axis.text.x = element_text(size = 10))

## ----pattern-preview----------------------------------------------------------
# Preview employment patterns
preview_bw_patterns("employment")

## ----contract-patterns--------------------------------------------------------
# Preview contract patterns
preview_bw_patterns("contracts", show_patterns = TRUE)

## ----bw-bar-charts, fig.height = 8--------------------------------------------
# Create sample data with employment statuses
pattern_data <- data.frame(
  employment_status = c("disoccupato", "occ_ft", "occ_pt", "over_ft_ft"),
  count = c(150, 800, 300, 200),
  region = rep(c("North", "South"), 2)
)

# Standard B&W version with solid borders
p1 <- ggplot(pattern_data, aes(x = employment_status, y = count, fill = employment_status)) +
  geom_col(color = "black", size = 0.5, alpha = 0.8) +
  scale_fill_vecshift_bw("employment") +
  labs(
    title = "Employment by Status - Improved B&W",
    subtitle = "Using lighter grays with solid borders",
    x = "Employment Status",
    y = "Count"
  ) +
  theme_vecshift() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "bottom"
  )

# Faceted version showing regional differences
p2 <- ggplot(pattern_data, aes(x = employment_status, y = count, fill = employment_status)) +
  geom_col(color = "black", size = 0.4, alpha = 0.8) +
  scale_fill_vecshift_bw("employment") +
  facet_wrap(~ region, ncol = 2) +
  labs(
    title = "Regional Employment Distribution",
    subtitle = "B&W visualization with clear distinctions",
    x = "Employment Status",
    y = "Count"
  ) +
  theme_vecshift() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "bottom",
    strip.background = element_rect(fill = "#F4F6F7", color = "black")
  )

grid.arrange(p1, p2, ncol = 1)

## ----bw-timeseries------------------------------------------------------------
# Create time series data
ts_data <- expand.grid(
  month = 1:12,
  employment_status = c("occ_ft", "occ_pt", "disoccupato")
)
ts_data$count <- c(
  1000 + 50 * sin(ts_data$month[ts_data$employment_status == "occ_ft"] * pi/6) + rnorm(12, 0, 20),
  300 + 30 * cos(ts_data$month[ts_data$employment_status == "occ_pt"] * pi/4) + rnorm(12, 0, 15),
  150 + 20 * sin(ts_data$month[ts_data$employment_status == "disoccupato"] * pi/3) + rnorm(12, 0, 10)
)

# Get employment line types
employment_lines <- vecshift_linetypes(c("occ_ft", "occ_pt", "disoccupato"), style = "employment")

ggplot(ts_data, aes(x = month, y = count, 
                    color = employment_status, 
                    linetype = employment_status)) +
  geom_line(size = 1.2) +
  geom_point(size = 2.5, alpha = 0.8) +
  scale_color_vecshift("main_bw") +
  scale_linetype_manual(values = employment_lines) +
  scale_x_continuous(breaks = 1:12, labels = month.abb) +
  labs(
    title = "Employment Trends with Distinct Line Patterns",
    subtitle = "Combining color and line type for maximum accessibility",
    x = "Month",
    y = "Employment Count",
    color = "Employment Status",
    linetype = "Employment Status"
  ) +
  theme_vecshift(grid = "major") +
  theme(
    legend.position = "bottom",
    legend.box = "horizontal"
  )

## ----bw-stacked-areas---------------------------------------------------------
# Create stacked area data
library(data.table)
area_data <- as.data.table(ts_data)[, .(total = sum(count)), by = .(month, employment_status)]

ggplot(area_data, aes(x = month, y = total, fill = employment_status)) +
  geom_area(position = "stack", alpha = 0.8, color = "black", size = 0.3) +
  scale_fill_vecshift_bw("employment") +
  scale_x_continuous(breaks = 1:12, labels = month.abb) +
  labs(
    title = "Employment Composition Over Time",
    subtitle = "Stacked areas with improved B&W palette and borders",
    x = "Month",
    y = "Total Employment",
    fill = "Employment Status",
    caption = "Patterns: unemployed (diagonal), full-time (solid), part-time (dots)"
  ) +
  theme_vecshift(grid = "major") +
  theme(
    legend.position = "bottom",
    plot.caption = element_text(hjust = 0, size = 9, face = "italic")
  )

## ----pattern-strategy---------------------------------------------------------
# Show pattern mapping for employment data
patterns <- vecshift_patterns("employment")
pattern_summary <- data.frame(
  Status = names(patterns),
  Pattern = sapply(patterns, function(x) x$pattern),
  Description = sapply(patterns, function(x) x$description),
  Usage = c(
    "Clear diagonal lines indicate unemployment periods",
    "Solid fill for continuous full-time employment",
    "Dots indicate intermittent part-time work",
    "Crosshatch shows complex full-time overlaps",
    "Reverse diagonal for part-time overlaps",
    "Weave pattern for mixed employment types",
    "Horizontal lines for transition periods"
  ),
  stringsAsFactors = FALSE
)

knitr::kable(pattern_summary, 
             caption = "Employment Status Pattern Mapping")

## ----linetype-strategy--------------------------------------------------------
# Show line type mapping
line_types <- vecshift_linetypes(c("occ_ft", "occ_pt", "disoccupato", "over_ft_ft"), 
                                style = "employment")
linetype_summary <- data.frame(
  Status = names(line_types),
  LineType = line_types,
  Visual_Meaning = c(
    "Solid line represents continuous employment",
    "Dashed line shows intermittent work patterns", 
    "Long dashes indicate unemployment gaps",
    "Dot-dash pattern for overlapping employment"
  ),
  stringsAsFactors = FALSE
)

knitr::kable(linetype_summary, 
             caption = "Employment Status Line Type Mapping")

## ----accessibility-test-new---------------------------------------------------
cat("Testing new main_bw palette accessibility:\n")
test_vecshift_accessibility("main_bw")

cat("\n\nComparing with old B&W palette:\n")
# Test old palette for comparison
old_palette_colors <- c("#000000", "#2C2C2C", "#4A4A4A", "#6E6E6E", "#8C8C8C")

## ----set-default, eval = FALSE------------------------------------------------
# # Set vecshift theme as default
# set_vecshift_theme(base_size = 12, grid = "major")
# 
# # All subsequent ggplot2 plots will use vecshift theme
# # Reset when done
# reset_default_theme()

## ----custom-colors------------------------------------------------------------
# Get specific employment colors
key_colors <- get_employment_colors(c("occ_ft", "occ_pt", "disoccupato"))
print(key_colors)

# Use in custom visualization
ggplot(sample_data[employment_status %in% names(key_colors)], 
       aes(x = month, y = count, color = employment_status)) +
  geom_smooth(method = "loess", se = FALSE, size = 1.5) +
  scale_color_manual(values = key_colors) +
  labs(
    title = "Employment Trends with Custom Colors",
    subtitle = "Smoothed trends using specific vecshift colors",
    x = "Month",
    y = "Count",
    color = "Employment Status"
  ) +
  theme_vecshift()

## ----integration, eval = FALSE------------------------------------------------
# # Example workflow (not run due to data requirements)
# #
# # # Process employment data
# # processed_data <- vecshift(employment_records, classify_status = TRUE)
# #
# # # Analyze patterns
# # status_patterns <- analyze_status_patterns(processed_data)
# #
# # # Visualize with vecshift theme
# # ggplot(status_patterns$duration_summary, aes(x = status, y = mean_duration)) +
# #   geom_col(aes(fill = status)) +
# #   scale_fill_vecshift("employment") +
# #   theme_vecshift() +
# #   labs(title = "Average Duration by Employment Status")


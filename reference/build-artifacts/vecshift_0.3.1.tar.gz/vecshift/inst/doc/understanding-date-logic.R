## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5
)

## ----setup--------------------------------------------------------------------
library(vecshift)
library(data.table)

## ----contract-example---------------------------------------------------------
# Example: January contract
contract_start <- as.Date("2023-01-01")
contract_end <- as.Date("2023-01-31")

# Calculate duration
duration <- as.numeric(contract_end - contract_start + 1)
cat("Contract duration:", duration, "days\n")
cat("Person works from:", format(contract_start, "%B %d"), 
    "to", format(contract_end, "%B %d"), "(both days inclusive)\n")

## ----date-logic---------------------------------------------------------------
# Example: Contract ends January 31st
contract_end <- as.Date("2023-01-31")
# The end event is at FINE
event_date <- contract_end
# Unemployment adjustment happens during processing
unemployment_start <- contract_end + 1  # Still starts Feb 1 after adjustment

cat("Last day of work:", format(contract_end, "%B %d, %Y"), "\n")
cat("End event created at:", format(event_date, "%B %d, %Y"), "\n")
cat("First day unemployed (after adjustment):", format(unemployment_start, "%B %d, %Y"), "\n")

## ----event-creation-----------------------------------------------------------
# Create sample employment data
employment_data <- data.table(
  id = 1:2,
  cf = c("PERSON001", "PERSON001"),
  INIZIO = as.Date(c("2023-01-01", "2023-04-01")),
  FINE = as.Date(c("2023-03-31", "2023-06-30")),
  prior = c(1, 0)
)

print("Original employment data:")
print(employment_data)

# The new vecshift creates events at FINE (not FINE+1)
# End events now occur ON the contract end date
cat("\nIn the new logic:\n")
cat("- End events are created at FINE\n")
cat("- Unemployment periods are adjusted afterward (inizio+1, fine-1)\n")

## ----consecutive-contracts----------------------------------------------------
consecutive_data <- data.table(
  id = 1:2,
  cf = rep("PERSON001", 2),
  inizio = as.Date(c("2023-01-01", "2023-04-01")),
  fine = as.Date(c("2023-03-31", "2023-06-30")),
  prior = c(1, 0)
)

print("Consecutive contracts:")
print(consecutive_data)

# Check if there's unemployment between contracts
first_end <- consecutive_data$fine[1]
second_start <- consecutive_data$inizio[2]
gap_duration <- as.numeric(second_start - first_end - 1)

cat("\nFirst contract ends:", format(first_end, "%B %d"), "\n")
cat("Second contract starts:", format(second_start, "%B %d"), "\n")
cat("Unemployment duration:", gap_duration, "days\n")

if (gap_duration == 0) {
  cat("No unemployment gap - contracts are consecutive!\n")
}

## ----gap-between-contracts----------------------------------------------------
gap_data <- data.table(
  id = 1:2,
  cf = rep("PERSON001", 2),
  inizio = as.Date(c("2023-01-01", "2023-03-15")),
  fine = as.Date(c("2023-02-28", "2023-05-31")),
  prior = c(1, 0)
)

print("Contracts with gap:")
print(gap_data)

# Calculate unemployment period
first_end <- gap_data$fine[1]
second_start <- gap_data$inizio[2]
gap_duration <- as.numeric(second_start - first_end - 1)

unemployment_start <- first_end + 1
unemployment_end <- second_start - 1

cat("\nFirst contract ends:", format(first_end, "%B %d"), "\n")
cat("Unemployment period:", format(unemployment_start, "%B %d"), "to", 
    format(unemployment_end, "%B %d"), "\n")
cat("Second contract starts:", format(second_start, "%B %d"), "\n")
cat("Total unemployment days:", gap_duration, "\n")

## ----overlapping-contracts----------------------------------------------------
overlap_data <- data.table(
  id = 1:2,
  cf = rep("PERSON001", 2),
  inizio = as.Date(c("2023-01-01", "2023-03-01")),
  fine = as.Date(c("2023-06-30", "2023-04-30")),
  prior = c(1, 0)
)

print("Overlapping contracts:")
print(overlap_data)

# The vecshift function would generate events at these dates
cat("\nEvents would be created at:\n")
cat("- Contract 1 start:", format(overlap_data$inizio[1]), "(+1)\n")
cat("- Contract 1 end:", format(overlap_data$fine[1]), "(-1)\n")
cat("- Contract 2 start:", format(overlap_data$inizio[2]), "(+1)\n")
cat("- Contract 2 end:", format(overlap_data$fine[2]), "(-1)\n")

# The cumulative sum would show overlapping employment
cat("\nCumulative employment levels (arco):\n")
cat("- Before March 1: arco = 1 (single employment)\n")
cat("- March 1 - April 30: arco = 2 (overlapping employment)\n")
cat("- May 1 - June 30: arco = 1 (single employment)\n")

# Identify overlap period
overlap_start <- overlap_data$inizio[2]
overlap_end <- min(overlap_data$fine)
cat("\nOverlapping period:", format(overlap_start, "%B %d"), "to", 
    format(overlap_end, "%B %d"), "\n")
cat("During this period: arco = 2 (multiple employment)\n")

## ----duration-calculations----------------------------------------------------
# Create data with both employment and unemployment periods
mixed_data <- data.table(
  id = 1:2,
  cf = rep("PERSON001", 2),
  inizio = as.Date(c("2023-01-01", "2023-04-01")),
  fine = as.Date(c("2023-02-28", "2023-06-30")),
  prior = c(1, 0)
)

# Calculate employment durations (inclusive)
emp_duration_1 <- as.numeric(mixed_data$fine[1] - mixed_data$inizio[1] + 1)
emp_duration_2 <- as.numeric(mixed_data$fine[2] - mixed_data$inizio[2] + 1)

# Calculate unemployment duration
unemp_duration <- as.numeric(mixed_data$inizio[2] - mixed_data$fine[1] - 1)

cat("Employment periods:\n")
cat("  Contract 1:", emp_duration_1, "days (Jan 1 - Feb 28, inclusive)\n")
cat("  Contract 2:", emp_duration_2, "days (Apr 1 - Jun 30, inclusive)\n")
cat("\nUnemployment period:", unemp_duration, "days (Mar 1 - Mar 31)\n")

# Verify total coverage
total_days <- as.numeric(max(mixed_data$fine) - min(mixed_data$inizio) + 1)
accounted_days <- emp_duration_1 + emp_duration_2 + unemp_duration
cat("\nTotal period:", total_days, "days\n")
cat("Accounted for:", accounted_days, "days\n")
cat("Complete coverage:", total_days == accounted_days, "\n")

## ----data-quality-------------------------------------------------------------
# Create data with various quality issues
problem_data <- data.table(
  id = 1:4,
  cf = rep("PERSON001", 4),
  inizio = as.Date(c("2023-01-01", "2023-03-01", "2023-05-01", "2023-07-15")),
  fine = as.Date(c("2023-02-28", "2023-02-15", "2023-05-01", "2023-07-10")),  # Issues!
  prior = c(1, 0, 1, 0)
)

print("Data with quality issues:")
print(problem_data)

# Basic validation can be done with simple R operations
cat("\nValidation Results:\n")
invalid_ranges <- sum(problem_data$fine < problem_data$inizio, na.rm = TRUE)
zero_duration <- sum(problem_data$fine == problem_data$inizio, na.rm = TRUE)
cat("Invalid date ranges:", invalid_ranges, "\n")
cat("Zero duration contracts:", zero_duration, "\n")

# Identify specific problems
invalid_rows <- which(problem_data$fine < problem_data$inizio)
zero_duration_rows <- which(problem_data$fine == problem_data$inizio)

if (length(invalid_rows) > 0) {
  cat("\nInvalid ranges (FINE < INIZIO) in rows:", invalid_rows, "\n")
}
if (length(zero_duration_rows) > 0) {
  cat("Zero duration contracts in rows:", zero_duration_rows, "\n")
}

## ----vecshift-analysis--------------------------------------------------------
# Analyze employment patterns using vecshift
clean_data <- data.table(
  id = 1:3,
  cf = rep("PERSON001", 3),
  INIZIO = as.Date(c("2023-01-01", "2023-04-01", "2023-07-01")),
  FINE = as.Date(c("2023-03-31", "2023-05-31", "2023-09-30")),
  prior = c(1, 0, 1)
)

# Use vecshift to create temporal segments
result <- vecshift(clean_data)

print("Temporal segments with employment status:")
print(result)

# Calculate employment statistics
total_duration <- as.numeric(sum(result$durata))
employment_duration <- as.numeric(sum(result$durata[result$arco > 0]))
employment_rate <- employment_duration / total_duration

cat("\nEmployment statistics:\n")
cat("Employment rate:", round(employment_rate, 3), "\n")
cat("Total segments:", nrow(result), "\n")

## ----vecshift-processing------------------------------------------------------
# Example data
employment_data <- data.table(
  id = 1:3,
  cf = c("P001", "P001", "P002"),
  INIZIO = as.Date(c("2023-01-01", "2023-06-01", "2023-02-01")),
  FINE = as.Date(c("2023-05-31", "2023-12-31", "2023-11-30")),
  prior = c(1, 0, 1)
)

# Process with default status classification
result_with_status <- vecshift(employment_data)
print(result_with_status[1:5])

# Process without status classification (raw segments only)
result_raw <- vecshift(employment_data, classify_status = FALSE)
print(result_raw[1:5])

## ----custom-status, eval=FALSE------------------------------------------------
# # Create custom classification rules
# custom_rules <- create_custom_status_rules(
#   unemployment_threshold = 30,  # Longer threshold
#   custom_labels = list(
#     unemployed_short = "job_seeking",
#     unemployed_long = "long_term_unemployed"
#   )
# )
# 
# # Apply custom classification
# result_custom <- vecshift(employment_data, status_rules = custom_rules)

## ----validation-example-------------------------------------------------------
# Before processing, always check data quality
has_invalid_dates <- any(employment_data$FINE < employment_data$INIZIO, na.rm = TRUE)

if (has_invalid_dates) {
  warning("Date issues detected - review data before processing")
}

## ----date-formats-------------------------------------------------------------
# vecshift expects Date objects - convert if needed
numeric_dates <- c(19358, 19387)  # Days since 1970-01-01
char_dates <- c("2023-01-01", "2023-01-30")

# Convert to Date objects
dates_from_numeric <- as.Date(numeric_dates, origin = "1970-01-01")
dates_from_char <- as.Date(char_dates)

print("Date conversions:")
print(list(from_numeric = dates_from_numeric, 
           from_character = dates_from_char))

